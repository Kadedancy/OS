/*#pragma once

void syscall_handler(struct InterruptContext* ctx);*/